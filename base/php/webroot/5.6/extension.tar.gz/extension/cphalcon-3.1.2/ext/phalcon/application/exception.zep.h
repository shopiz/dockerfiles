
extern zend_class_entry *phalcon_application_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Application_Exception);

